<?php
require_once 'bd.php';
require_once 'sesiones.php';
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sistema de gestión de tickets</title>
    <style>
        .cabecera {
            background-color: #007BFF; 
            padding: 10px;
            margin: 0px 0px 15px 0px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            color: white;
            font-family: Arial, sans-serif;
        }
        .cabecera .titulo {
            font-size: 1.5em;
            font-weight: bold;
        }
        .cabecera .acciones {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .cabecera .acciones img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
        }
        .cabecera .acciones button {
            background-color: #FF5722;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            float: right;
        }
        .cabecera .acciones button:hover {
            background-color: #E64A19;
        }
        .logout{
            float: right;

        }
    </style>
</head>
<body>
    <div class="cabecera">
        <div class="titulo">Ticket Manager</div>
        <div class="acciones">
            <?php
            
            if (isset($_SESSION['usuario']['id'])) {
                echo "<a href='perfil.php?id={$_SESSION['usuario']['id']}'>
                <img src='{$_SESSION['usuario']['ruta_pfp']}' alt='Perfil'>
                </a>";
                echo "<form action='logout.php?redirigido=logout' method='GET' style='float: right;'>
                <button type='submit'>Cerrar Sesión</button>
                </form>";
            }elseif (basename($_SERVER['PHP_SELF']) == 'login.php') {
                echo "<form action='registro.php' method='GET' style='float: right;'>
                <button type='submit'>Registrarse</button>
                </form>";
            }else {
                echo "<form action='login.php' method='GET' style='float: right;'>
                <button type='submit'>Iniciar sesión</button>
                </form>";
            }
            session_abort();
    ?>
        </div>
    </div>
</body>
</html>
