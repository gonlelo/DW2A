<?php
require_once 'bd.php';
require_once 'sesiones.php';
require 'cabecera.php';

comprobar_sesion();


$bd=crear_base();
if (isset($_POST['nombre'])) {
    
    $query = "UPDATE empleados SET nombre='{$_POST['nombre']}' WHERE id = {$_SESSION['usuario']['id']}";
    $bd->query($query);
    $_SESSION['usuario']['nombre'] = $_POST['nombre'];
    $cambio = true;
}
if (isset($_POST['apellido'])) {

    $query = "UPDATE empleados SET apellido='{$_POST['apellido']}' WHERE id = {$_SESSION['usuario']['id']}";
    $bd->query($query);
    $_SESSION['usuario']['apellido'] = $_POST['apellido'];
    $cambio = true;
}
if (isset($_POST['telefono'])) {

    $query = "UPDATE empleados SET teléfono='{$_POST['telefono']}' WHERE id = {$_SESSION['usuario']['id']}";
    $bd->query($query);
    $_SESSION['usuario']['teléfono'] = $_POST['telefono'];
    $cambio = true;
}
if (isset($_POST['pais_nacimiento'])) {

    $query = "UPDATE empleados SET pais_nacimiento='{$_POST['pais_nacimiento']}' WHERE id = {$_SESSION['usuario']['id']}";
    $bd->query($query);
    $_SESSION['usuario']['pais_nacimiento'] = $_POST['pais_nacimiento'];
    $cambio = true;
}


//Cambiar la imagen de perfil
if (isset($_FILES['imagen'])&& $_FILES['imagen']['tmp_name'] !== '') {
    $nombreArchivo = $_FILES['imagen']['name'];
    $temporalArchivo = $_FILES['imagen']['tmp_name'];
    
    $directorioDestino = "pfps/";
    

    if (!is_dir($directorioDestino)) {
        mkdir($directorioDestino, 0777, true);
    }

    $rutaArchivo = $directorioDestino .basename($nombreArchivo) ;

    move_uploaded_file($temporalArchivo, $rutaArchivo);

// Meter la nueva imagen en la base de datos
$query = "UPDATE empleados SET ruta_pfp='{$rutaArchivo}' WHERE id = {$_SESSION['usuario']['id']}";
$bd->query($query);
$_SESSION['Usuario']['ruta_pfp'] = $rutaArchivo;
echo"<p style='color:orange;'>Cierra y abre sesión para ver tu nueva foto en la cabecera</p>";
}

?>

<!----------------------------------------------------------------------------------------->


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php 
if (isset($cambio)) {
    echo "<p style='color: green'>Cambios realizados correctamente</p>";
}
echo "<form action='perfil.php'} method='POST' enctype='multipart/form-data'>";
        $db = crear_base();
        $query1 = "SELECT ruta_pfp FROM empleados WHERE id={$_SESSION['usuario']['id']}";
        $resul1 = $db->query($query1);
        if($resul1->rowCount() >= 1){
            foreach($resul1 as $fila){
            // Si el archivo es .png o .jpg se muestra la imagen
            $fila['ruta_pfp'] = str_replace('\\', '/', $fila['ruta_pfp']);
            // Imagen del perfil
            echo "<img src='{$fila['ruta_pfp']}' alt='Foto de perfil' style='width:200px'><br><br>"; 
    }
}
echo "<input type='file' name='imagen' id='imagen'><br><br>";
    ?>
    
    Nombre:<br>
    <?php 
        if (isset($_SESSION['usuario']['nombre'])) {
            echo "<input value='{$_SESSION['usuario']['nombre']}' type='text' name='nombre' required><br><br>"; 
        } else {
            echo "<input value='' type='text' name='nombre' placeholder='Introduce tu nombre' required><br><br>";
        }
    ?>
    
    Apellido:<br>
    <?php 
        if (isset($_SESSION['usuario']['apellido'])) {
            echo "<input value='{$_SESSION['usuario']['apellido']}' type='text' name='apellido' required><br><br>"; 
        } else {
            echo "<input value='' type='text' name='apellido' placeholder='Introduce tu apellido' required><br><br>";
        }
    ?>
    
    Teléfono (+34):<br>
    <?php 
        if (isset($_SESSION['usuario']['teléfono'])) {
            echo "<input value='{$_SESSION['usuario']['teléfono']}' type='text' name='telefono'><br><br>"; 
        } else {
            echo "<input value='' type='text' name='telefono' placeholder='Introduce tu número de teléfono'><br><br>";
        }
    ?>
    
    País de Nacimiento:<br>
    <?php 
        if (isset($_SESSION['usuario']['pais_nacimiento'])) {
            echo "<input value='{$_SESSION['usuario']['pais_nacimiento']}' type='text' name='pais_nacimiento'><br><br>"; 
        } else {
            echo "<input value='' type='text' name='pais_nacimiento' placeholder='Introduce tu país de nacimiento'><br><br>";
        }
    ?>
    
    <input type="submit" value="Actualizar Perfil">
    
</form>
</body>
</html>