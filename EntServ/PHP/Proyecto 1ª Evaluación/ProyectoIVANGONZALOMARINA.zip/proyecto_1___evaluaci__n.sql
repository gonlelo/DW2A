-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 31-10-2024 a las 12:17:55
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `proyecto1ev`
--
CREATE DATABASE IF NOT EXISTS `proyecto1ev` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `proyecto1ev`;
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleados`
--
CREATE OR REPLACE TABLE `empleados` (
  `id` int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `apellido` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contraseña` varchar(100) NOT NULL,
  `teléfono` int(10),
  `ruta_pfp` varchar(100) DEFAULT 'pfps/default.png',
  `pais_nacimiento` varchar(50),
  `verificado` BOOLEAN DEFAULT 0,
  `cod_verificacion` varchar(8) UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `empleados`
--

INSERT INTO `empleados` (`id`, `nombre`, `apellido`, `email`, `contraseña`, `verificado`, `ruta_pfp`) VALUES
(1, 'Isidoro', 'Gangrenado Poyato', 'isidorogangrenado@soporte.empresa.com', '81dc9bdb52d04dc20036dbd8313ed055', 1, 'pfps/default.png'),
(2, 'Marta', 'Pincho Moruno', 'martapincho@soporte.empresa.com', '81dc9bdb52d04dc20036dbd8313ed055', 1, 'pfps/default.png'),
(3, 'Dolores', 'Miasma Musgo', 'doloresmiasma@empresa.com', '81dc9bdb52d04dc20036dbd8313ed055', 1, 'pfps/default.png'),
(4, 'Eva', 'Salmón Vejestorio', 'evasalmon@empresa.com', '81dc9bdb52d04dc20036dbd8313ed055', 1, 'pfps/default.png'),
(5, 'Pinocho', 'Cromosoma Fútbol', 'pinochocromosoma@empresa.com', '81dc9bdb52d04dc20036dbd8313ed055', 1, 'pfps/default.png');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tickets`
--
CREATE OR REPLACE TABLE `tickets` (
  `num` int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `título` varchar(50) NOT NULL,
  `mensaje` varchar(500) NOT NULL,
  `estado` varchar(11) NOT NULL DEFAULT 'Creado',
  `autor` int(11) DEFAULT NULL,
  `fecha` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ruta` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Estructura de tabla para la tabla `respuestas`
--

CREATE OR REPLACE TABLE `respuestas` (
  `num` int(11) PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `mensaje` varchar(500) NOT NULL,
  `autor` int(11) DEFAULT NULL,
  `ticket` int(11) DEFAULT NULL,
  `fecha` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
--

INSERT INTO `tickets` (`num`, `título`, `mensaje`, `estado`, `autor`) VALUES
(1, 'No me funciona internet', 'El internet no me funciona bien, se apaga y se enciende cuando quiere.', 'En proceso', 3),
(2, '¿Cómo accedo a mi perfil?', 'Me gustaría cambiar mi foto.', 'Solucionado', 4);

INSERT INTO `respuestas` (`num`, `mensaje`, `ticket`, `autor`) VALUES
(1, 'Prueba a reiniciar el router', 1, 1  ),
(2, 'Hola, pincha en el icono de tu perfil arriba a la derecha. Después pulsa <i>cambiar foto de perfil</i>', 2, 2  );

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `empleados`
--
ALTER TABLE `empleados`
  -- ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indices de la tabla `tickets`
--
-- ALTER TABLE `tickets`
--   ADD PRIMARY KEY (`num`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
