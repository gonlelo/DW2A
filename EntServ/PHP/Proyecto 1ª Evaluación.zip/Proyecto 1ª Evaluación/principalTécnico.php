<?php 
include 'bd.php'; // Include the database configuration file
require_once 'sesiones.php'; // Include session functions

// Ensure the session is started and that the user is a technician
comprobar_sesion();
if ($_SESSION['tipo'] != 1) {
    header("Location: login.php?denegado=técnico");
    exit();
}
if ($_SERVER["REQUEST_METHOD"] == "POST")  {
	if (isset($_POST['eliminar'])) {
		borrarTicket($_POST['eliminar']);
	}
}
?>

<!DOCTYPE html>
    <html>
        <head>
            <meta charset = "UTF-8">
            <title>Vista tecnico</title>
            <style>
                div{
                    padding: 0.5em;
                    border: 4px solid #CC99CC;
                    border-radius: 2em;
                    margin-bottom: 1em;
                    width: 60%;
                }
        </style>
	</head>
	<body>
		<a href="login.php" style="float: right">Cerrar Sesión </a>
		<h1>Lista de tickets, hola moderador</h1>		
		<?php
			$bd=crear_base();
			
			//Sacar todos los tickets
			$query = "SELECT tck.num, tck.título, tck.mensaje, tck.estado, emp.nombre, emp.apellido FROM tickets tck LEFT JOIN empleados emp ON tck.autor = emp.id;";
			$resul = $bd->query($query);
			if($resul->rowCount() >= 1){
				foreach ($resul as $ticket) {
					echo "<a href='ticket.php?id={$ticket['num']}' style='text-decoration: none;'>";
					echo "<div>";
					echo "<h1><b>#{$ticket['num']}</b> {$ticket['título']}</h1>";
					echo "<p>{$ticket['mensaje']}</p><br>";
					echo "<p><b>{$ticket['estado']}</b></p>";
					echo "<form method='POST' style='display:inline;'> 
					<input type='hidden' name='eliminar' value='{$ticket['num']}'>
					<button type='submit' style='text-align: left'>Borrar</button>
					</form>";
					echo "<p style='text-align: right'>Autor: {$ticket['nombre']} {$ticket['apellido']}</p>";
					echo "</div>";
					echo "</a>";
				}
			}else {
				echo "<p>Nadie ha creado ningún ticket. Disfruta de tu descanso</p>";
			}
			// Cerrar la conexión
			$bd = null;
		?>
	</body>
</html>
